package com.propmisespages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class PromisesPage extends BasePageObject {

	WebDriver driver;
	WebElement promisor,searchbtn,logout;
	public PromisesPage(WebDriver driver) {
		super(driver);
		this.driver=driver;
		// TODO Auto-generated constructor stub
	}
	public boolean searchPromise()
	{
		try
		{
			promisor=driver.findElement(By.id("cboEmp"));
			
			Select promisordd=new Select(promisor);
			promisordd.selectByVisibleText("Sonali test");
			searchbtn=driver.findElement(By.name("btnSearch"));
			searchbtn.click();
			waitUntilPageIsLoaded();
			
			
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Got Exception : "+e);
			return false;
		}
		
	}
	public boolean logout()
	{
		try
		{
			logout.click();
			log.info("Logout Successfully");
			return true;
		}
		catch(Exception e)
		{
			System.out.println("Got Exception : "+e);
			return false;
		}
	}
}
